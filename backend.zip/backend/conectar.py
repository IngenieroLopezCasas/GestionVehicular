import pyodbc
from flask import Flask, request, jsonify
from flask_cors import CORS

app = Flask(__name__)
CORS(app)

DB_CONNECTION = "DRIVER={SQL Server};SERVER=DESKTOP-HT478MM;DATABASE=ControlVehicular;UID=UserCVehicular;PWD=V3h1cul9r"


def get_db_connection():
    return pyodbc.connect(DB_CONNECTION)

# # Función auxiliar
# def get_db_connection():
#     return pyodbc.connect(DB_CONNECTION)

# # Obtener todos los vehículos
# @app.route("/vehicles", methods=["GET"])
# def obtener_vehiculos():
#     conn = get_db_connection()
#     cursor = conn.cursor()
#     cursor.execute("SELECT * FROM Vehiculos")
#     columnas = [column[0] for column in cursor.description]
#     resultados = [dict(zip(columnas, row)) for row in cursor.fetchall()]
#     conn.close()
#     return jsonify(resultados)

# # Actualizar un vehículo
# @app.route("/vehicles/<int:id>", methods=["PUT"])
# def update_vehicle(id):
#     data = request.json
#     conn = get_db_connection()
#     cursor = conn.cursor()
#     cursor.execute("""
#         UPDATE Vehiculos
#         SET marca=?, modelo=?, placas=?, color=?, serie=?, unidad=?, transmision=?, iddepartamento=?, submarca=?, estatus=?, km=?
#         WHERE IdVehiculos=?
#     """, (
#         data["marca"], data["modelo"], data["placas"], data["color"], data["serie"],
#         data["unidad"], data["transmision"], data["iddepartamento"], data["submarca"],
#         data["estatus"], data.get("km", 0), id
#     ))
#     conn.commit()
#     conn.close()
#     return jsonify({"mensaje": "Vehículo actualizado correctamente"})

# # Eliminar un vehículo
# @app.route("/vehicles/<int:id>", methods=["DELETE"])
# def delete_vehicle(id):
#     conn = get_db_connection()
#     cursor = conn.cursor()
#     cursor.execute("DELETE FROM Vehiculos WHERE IdVehiculos = ?", (id,))
#     conn.commit()
#     conn.close()
#     return jsonify({"mensaje": "Vehículo eliminado correctamente"})




@app.route("/vehicles", methods=["GET"])
def get_vehicles():
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute("SELECT * FROM Vehiculos WHERE Estatus=1")
    rows = cursor.fetchall()
    columnas = [column[0] for column in cursor.description]
    vehicles = [dict(zip(columnas, row)) for row in rows]
    conn.close()
    return jsonify(vehicles)



@app.route("/vehicles/Agregar", methods=["POST"])
def add_vehicle():
    data = request.json
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute("""
        INSERT INTO Vehiculos 
        (marca, modelo, placas, color, serie, unidad, transmision, iddepartamento, submarca, estatus)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    """, (
        data["marca"], data["modelo"], data["placas"], data["color"], data["serie"],
        data["unidad"], data["transmision"], data["iddepartamento"], data["submarca"], 1
    ))
    conn.commit()
    conn.close()
    return jsonify({"mensaje": "Vehículo agregado correctamente"}), 201



@app.route("/vehicles/Actualizar/<int:id>", methods=["POST"])
def update_vehicle(id):
    data = request.json
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute("""
        UPDATE Vehiculos
        SET marca=?, modelo=?, placas=?, color=?, serie=?, unidad=?, transmision=?, iddepartamento=?, submarca=?, estatus=?
        WHERE IdVehiculos=?
    """, (
        data["marca"], data["modelo"], data["placas"], data["color"], data["serie"],
        data["unidad"], data["transmision"], data["iddepartamento"], data["submarca"], data["estatus"], id
    ))
    conn.commit()
    conn.close()
    return jsonify({"mensaje": "Vehículo actualizado correctamente"})



''''
@app.route("/vehicles/<int:id>", methods=["DELETE"])
def delete_vehicle(id):
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute("DELETE FROM Vehiculos WHERE IdVehiculos = ?", (id,))
    conn.commit()
    conn.close()
    return jsonify({"mensaje": "Vehículo eliminado correctamente"})

    '''
@app.route("/vehicles/baja/<int:id>", methods=["POST"])
def delete_vehicle(id):
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute("UPDATE Vehiculos SET Estatus = 0 WHERE IdVehiculos = ?", (id))
    conn.commit()
    conn.close()
    return jsonify({"mensaje": "Vehículo dado de baja correctamente"})


# Iniciar servidor
if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000)
