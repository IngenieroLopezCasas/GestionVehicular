import React, { useState } from "react";
import api from "../services/api";
import { useNavigate, Link } from "react-router-dom";
import "./EntryForm.css";

const EntryForm = () => {
  const navigate = useNavigate();
  const [vehicleId, setVehicleId] = useState("");
  const [vehicleData, setVehicleData] = useState(null);
  const [entryData, setEntryData] = useState({
    km: "",
    gasolina: "",
    estado: "",
    entregadoPor: "",
  });

  const handleQrRead = async () => {
    try {
      const res = await api.get(`/vehicles`);
      const match = res.data.find(v => v.IdVehiculos === parseInt(vehicleId));
      if (match) {
        setVehicleData(match);
      } else {
        alert("Vehículo no encontrado");
        setVehicleData(null);
      }
    } catch (err) {
      console.error("Error al buscar vehículo:", err);
    }
  };

  const handleChange = (e) => {
    setEntryData({ ...entryData, [e.target.name]: e.target.value });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      await api.post("/entradas", {
        ...entryData,
        idvehiculo: vehicleId,
        fecha: new Date().toISOString(),
      });
      alert("Entrada registrada correctamente");
      navigate("/vehicles");
    } catch (error) {
      console.error("Error al guardar entrada:", error);
      alert("Error al guardar la entrada");
    }
  };

  return (
    <div className="entry-container">
      <h2 className="entry-title">Registro de Entrada de Vehículo</h2>

      <div className="qr-input">
        <label>Escanear o ingresar ID del Vehículo:</label>
        <input
          type="number"
          value={vehicleId}
          onChange={(e) => setVehicleId(e.target.value)}
          placeholder="Ej. 12"
          required
        />
        <button onClick={handleQrRead}>Buscar Vehículo</button>
      </div>

      <div className="entry-grid">
        <div className="entry-left">
          <h3>Datos del Vehículo</h3>
          {vehicleData ? (
            <ul>
              <li><strong>Placas:</strong> {vehicleData.Placas}</li>
              <li><strong>Marca:</strong> {vehicleData.Marca}</li>
              <li><strong>Submarca:</strong> {vehicleData.Submarca}</li>
              <li><strong>Modelo:</strong> {vehicleData.Modelo}</li>
              <li><strong>Color:</strong> {vehicleData.Color}</li>
              <li><strong>Unidad:</strong> {vehicleData.Unidad}</li>
              <li><strong>Transmisión:</strong> {vehicleData.Transmision}</li>
            </ul>
          ) : (
            <p className="vehicle-empty">No hay datos cargados</p>
          )}
        </div>

        <div className="entry-right">
          <h3>Datos de Entrada</h3>
          <form onSubmit={handleSubmit}>
            <div className="form-group">
              <label>Kilometraje actual:</label>
              <input
                type="number"
                name="km"
                value={entryData.km}
                onChange={handleChange}
                required
              />
            </div>

            <div className="form-group">
              <label>Nivel de gasolina (%):</label>
              <input
                type="number"
                name="gasolina"
                min="0"
                max="100"
                value={entryData.gasolina}
                onChange={handleChange}
                required
              />
            </div>

            <div className="form-group">
              <label>Estado físico:</label>
              <textarea
                name="estado"
                value={entryData.estado}
                onChange={handleChange}
                rows="4"
                required
              ></textarea>
            </div>

            <div className="form-group">
              <label>Entregado por:</label>
              <input
                type="text"
                name="entregadoPor"
                value={entryData.entregadoPor}
                onChange={handleChange}
                required
              />
            </div>

            <div className="form-buttons">
              <button type="submit" className="btn-submit">Registrar Entrada</button>
              <Link to="/vehicles" className="btn-cancel">Cancelar</Link>
            </div>
          </form>
        </div>
      </div>
    </div>
  );
};

export default EntryForm;
