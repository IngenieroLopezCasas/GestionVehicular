// Home.js
import React, { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import { Plus, Edit, Trash } from "lucide-react";
import api from "../services/api"; // Asegúrese de que este archivo exista

const Home = () => {
  const [vehicles, setVehicles] = useState([]);

  useEffect(() => {
    api.get("/vehicles")
      .then((res) => setVehicles(res.data, console.log(res, 'estoy en home')))
      .catch((err) => console.error("Error al obtener vehículos", err));
  }, []);

  const deleteVehicle = (id) => {
    if (window.confirm("¿Está seguro que desea eliminar este vehículo?")) {
      api.post(`/vehicles/baja/${id}`)
        .then(() => {
          setVehicles(vehicles.filter((v) => v.IdVehiculos !== id));
          alert("Vehículo eliminado");
        })
        .catch((err) => alert("Error al eliminar el vehículo"));
    }
  };

  return (
    <div className="container">
      <header>
        <h1 className="header-title">Sistema de Información Vehicular</h1>
        <p className="header-subtitle">CRT</p>
      </header>

      <Link to="/bitacora" className="btn btn-secondary mt-4">
        Ir a Bitácora de Vehículos
      </Link>

      <div className="main-content">
        <div className="cards-grid">
          {vehicles.map((vehicle) => (
            <div key={vehicle.IdVehiculos} className="card">
              <div className="card-buttons">
                <Link to={`/edit-vehicle/${vehicle.IdVehiculos}`}>
                  <button className="button-icon"><Edit size={16} /></button>
                </Link>
                <button className="button-icon" onClick={() => deleteVehicle(vehicle.IdVehiculos)}>
                  <Trash size={16} />
                </button>
              </div>
              <div className="card-image">
                <span>No Image</span>
              </div>
              <h3 className="card-title">{vehicle.Marca} {vehicle.Submarca}</h3>
              <p className="card-text">{vehicle.Modelo} - {vehicle.Placas}</p>
            </div>
          ))}
        </div>
      </div>

      <Link to="/add-vehicle" className="floating-button" title="Agregar">
        <Plus size={24} />
      </Link>
    </div>
  );
};

export default Home;
