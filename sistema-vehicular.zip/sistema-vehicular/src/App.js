import { BrowserRouter as Router, Routes, Route } from "react-router-dom";
import Home from "./components/home";
import VehicleDetails from "./components/vehicleDetails";
import AddVehicle from "./components/AddVehicle";
import VehicleList from "./components/VehicleList";
import Bitacora from "./components/Bitacora";
import RegistrarMarca from "./components/RegistraMarca";
import EditVehicle from "./components/EditVehicle";







function App() {
  return (
    <Router>
      <Routes>
        <Route path="/edit-vehicle/:id" element={<EditVehicle />} />
        <Route path="/" element={<Home />} />
        <Route path="/details/:id" element={<VehicleDetails />} />
        <Route path="/add-vehicle" element={<AddVehicle />} />
        <Route path="/vehicles" element={<VehicleList />} />
        <Route path="/bitacora" element={<Bitacora />} />
        <Route path="/edit-vehicle/:id" element={<EditVehicle />} />
        <Route path="/registrar-marca" element={<RegistrarMarca />} />
      </Routes>
    </Router>
  );
}

export default App;
